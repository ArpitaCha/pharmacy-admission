<?php

namespace App\Observers\wbscte;

class StateObserver
{
    //
}
