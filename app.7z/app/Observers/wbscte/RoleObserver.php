<?php

namespace App\Observers\wbscte;

class RoleObserver
{
    //
}
