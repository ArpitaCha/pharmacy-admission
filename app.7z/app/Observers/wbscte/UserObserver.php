<?php

namespace App\Observers\wbscte;

class UserObserver
{
    //
}
